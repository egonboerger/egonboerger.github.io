:p files/java.p
do putStrLn "please wait (starting the GUI)" :: IO (); main
:q
