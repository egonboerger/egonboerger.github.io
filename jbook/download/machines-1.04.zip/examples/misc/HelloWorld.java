// Example adapted from
// http://www.thrishna.com/java/examples/java/lang/HelloWorld.htm

public class HelloWorld{

   public static void main( String[] arg ){
     System.out.println( "Hello World" );
   }
}

