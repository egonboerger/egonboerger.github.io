interface I {
  int MAX = 100;
}

interface J {
  int MAX = 99;
}

public class A implements I, J {
  static void main(String args[]) {
  }
}
