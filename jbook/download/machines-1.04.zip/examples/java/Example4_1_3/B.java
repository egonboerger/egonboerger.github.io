interface I {
  int MAX = 100;
}

class A implements I {}
public class B extends A implements I {
   static void main(String args[]) {
   }
}
