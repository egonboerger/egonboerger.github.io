/** The user class, referencing and using the ersatz class R.
 */ 
public class RT {
  public  RT() {
    try {
      System.out.println("Hello...");
      RR rr = new RR();
      R r  = rr.getR();
      System.out.println("  r.r is " + r.r + ".");
      r.r = 300960;
      System.out.println("  r.r is set to " + r.r + ".");
      System.out.println("...bye.");
    } catch (Throwable e) { 
      System.out.println("Exception " + e.toString() + " in RT.main.");
    }
  }

}
