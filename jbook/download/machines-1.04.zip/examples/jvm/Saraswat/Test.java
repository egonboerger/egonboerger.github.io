/** Test harness for classloader examples. Loads the user class into
 * a newly constructed DelegatingLoader. 
 */
public class Test {
  DelegatingLoader loader;

  public void doIt(String arg) {
    try {
      String target = arg;
      this.loader = new DelegatingLoader("ersatz/");
      Class c = this.loader.loadClass(target);
      c.newInstance();
    } catch (Exception e) {
    System.out.println("Error " + e.toString() + " in Test.doIt.");
    }
  }
  public static void main(String argv[]) {
    Test t = new Test();
    t.doIt("RT");
  }
}
