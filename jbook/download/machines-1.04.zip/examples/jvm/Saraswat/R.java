public class R {
 public String r = "abc";
}
