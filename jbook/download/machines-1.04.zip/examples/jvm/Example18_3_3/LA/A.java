public class A {
    static {
	System.out.println("-I- LA/A.<clinit>()");
    }

    public A() {
	System.out.println("-I- LA/A.<init>()");
    }

}


