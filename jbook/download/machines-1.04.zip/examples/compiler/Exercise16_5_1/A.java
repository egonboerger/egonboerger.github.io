class A {
  static void m(boolean b) {
    lab: try { if (b) break lab; }
         finally { break lab; }
  }

  static void main(String[] argv) {
    m(true);
  }
}
