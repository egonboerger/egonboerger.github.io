class A {
  int m() {
    int i;
    try { i = 7; }
    finally { return 3; }
  }

  static void main(String[] argv) {
    System.out.println((new A()).m());
  }
}
