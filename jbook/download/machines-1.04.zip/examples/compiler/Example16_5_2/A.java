class A {
  static void m() {
    int i;
    if (true)
      return;
    else
      i = 2;
  }

  static void main(String[] argv) {
    m();
  }
}
