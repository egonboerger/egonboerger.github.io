class A {
  static void main(String[] argv) {
    boolean b = true;
    while (b ? true : true) ;
  }
}
