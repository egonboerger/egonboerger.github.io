class A {
  static void m(boolean b) {
    boolean z;
    while (b ? true : true) ;
    b = z;
  }

  static void main(String[] argv) {
     m(true);
  }
}
