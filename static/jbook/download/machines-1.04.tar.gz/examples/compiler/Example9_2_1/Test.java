class Test {
  static boolean m(boolean x, boolean y) {
   boolean z;
   if (x?z=y:false)
     return z;
   else
     return x;
  }

  static public void main(String[] argv) { }
}
