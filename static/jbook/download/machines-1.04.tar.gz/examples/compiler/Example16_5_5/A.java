class A {
  static void main(String[] argv) {
    int i;
    L: { if (true)
           break L;
         else
           i = 3;
    }
  }
} 
