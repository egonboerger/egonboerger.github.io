class A {
  private int x;
  public int y;
  public static int z;
}

class B extends A {
  private int x;

  public static void main(String[] argv) { }
}
