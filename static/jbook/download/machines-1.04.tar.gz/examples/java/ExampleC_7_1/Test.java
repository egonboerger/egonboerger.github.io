public class Test {
  public static void main(String[] argv) {
    int[][] a = null;
    a[0] = new int[0];
  }
}
