class Test {
   static long m(int i) {
     return i;
   }

   static void main(String args[]) {
     System.out.println(m(5));
   }
}
