class Test {
  int m() {
    int i;
    if (true) 
     return 0;
    else
     return i;
  }

  static public void main(String[] argv) { }
} 
