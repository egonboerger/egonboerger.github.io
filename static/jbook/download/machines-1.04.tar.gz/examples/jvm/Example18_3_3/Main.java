import java.io.*;

public class Main {
    static void main(String[] args) {
	Loader L = new Loader("L", ClassLoader.getSystemClassLoader());
	try {
	    Class Ac  = L.loadClass("A");
	    Object Ao = Ac.newInstance();
	    System.out.println("-I- Class A loaded and initialized");
	}
	catch (Throwable e) {
            System.out.println("Exception: Throwable");
	}
    }
}
