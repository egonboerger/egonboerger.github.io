public class B extends A {
    static {
	System.out.println("-I- LA/B.<clinit>()");
    }

    public B() {
	System.out.println("-I- LA/B.<init>()");
    }

    public A getA() { 
        System.out.println("-I- LA/B.getA()");
        return (A)this; 
    }

}
