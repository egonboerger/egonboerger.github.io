public class B {
    static {
	System.out.println("-I- L/B.<clinit>()");
    }

    public B() {
	System.out.println("-I- L/B.<init>()");
    }

    public A getA() { 
        System.out.println("-I- L/B.getA()");
        return (A)this; 
    }

}
