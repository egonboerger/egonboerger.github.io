public class A extends B {
    static {
	System.out.println("-I- L/A.<clinit>()");
    }

    public A() {
	System.out.println("-I- L/A.<init>()");
        m();
        n();
    }

    public void m() {
        System.out.println("-I- L/A.m()");
    }

    public void n() {
        System.out.println("-I- L/A.n()");
        System.out.println("-I- Try to call super.getA().n()");
        try {
          super.getA().n();
        }
        catch (LinkageError e) {
          System.out.println("-E- Strange, initialized class gets the following LinkageError:");
          e.printStackTrace();
        }
    }
}

