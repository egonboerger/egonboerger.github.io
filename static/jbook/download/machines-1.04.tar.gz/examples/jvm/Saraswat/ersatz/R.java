public class R {
  public int r; 
}
