public class RR {
  public R getR() {
    return new R();
  }
}
